export default function Home() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Bienvenue dans le tableau de bord Phantom 👻</h1>
      <p>Suivez vos publications, impressions, et résultats ici.</p>
    </div>
  );
}